#!/usr/bin/python3
class Square:
    """Represents an empty square."""
    
    
    pass
