0x06. Python - Classes and Objects
